/*
 *  Club Robot ESEO 2015
 *
 *  Package : Carte IHM
 *  Description : Variable global
 *  Auteur : Arnaud
 */

#include "config_global_vars.h"

global_data_storage_t global;

