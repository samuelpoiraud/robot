/*
 *  Club Robot ESEO 2015 - 2016
 *
 *  Fichier : QS_detection.h
 *  Package : Qualit� Soft
 *  Description : Module permettant de r�cup�rer les informations adversiare
 *  Auteur : Arnaud
 *  Version 20130518
 */

/** ----------------  Defines possibles  --------------------
 * aucun
 */

#ifndef QS_DETECTION_H
	#define QS_DETECTION_H

	#include "QS_all.h"

#endif /* ndef QS_DETECTION_H */
