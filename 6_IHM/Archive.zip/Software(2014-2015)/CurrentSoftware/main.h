/*
 *	Club Robot ESEO 2014
 *
 *	Fichier : main.h
 *	Package : Carte Principale
 *	Description : Ordonnancement de la carte Principale
 *	Auteur : Anthony
 *	Version 2012/01/14
 */

#include "QS/QS_all.h"


#ifndef MAIN_H
	#define MAIN_H

	void MAIN_process_it(Uint8 ms);

#endif /* ndef MAIN_H */
