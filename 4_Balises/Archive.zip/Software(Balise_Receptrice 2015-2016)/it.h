/*
 *  Club Robot ESEO 2015
 *
 *  Fichier : it.c
 *  Package : Balise r�ceptrice
 *  Description : Gestion des IT
 *  Auteur : Arnaud
 *  Version 200904
 */

#ifndef _IT_H
	#define _IT_H

	#include "QS/QS_all.h"
	void IT_init(void);

#endif	//def _IT_H
