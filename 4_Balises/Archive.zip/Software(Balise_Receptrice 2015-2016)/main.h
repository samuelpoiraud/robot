/*
 *	Club Robot 2015
 *
 *	Fichier : main.h
 *	Package : Balise receptrice
 *	Description : Main
 *	Auteur : Arnaud
 */

#ifndef MAIN_H
	#define MAIN_H

	#include "QS/QS_all.h"

#endif /* ndef MAIN_H */
