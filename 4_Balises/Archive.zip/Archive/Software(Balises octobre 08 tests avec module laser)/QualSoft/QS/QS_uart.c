/*
 *	Club Robot ESEO 2008 - 2009
 *	Archi-Tech'
 *
 *	Fichier : QS_uart.c
 *	Package : Qualite Soft
 *	Description : fonction d'utilisation des uart pour 
 *					interfacage rs232
 *	Auteur : Jacen
 *	Version 20081012
 */

#define QS_UART_C
#include "QS_uart.h"

#ifdef USE_UART1
	void UART1_putc(Uint8 mes)
	{
		while(BusyUART1());
		putcUART1(mes);	
	}
#endif /* def USE_UART1 */

#ifdef USE_UART2
	void UART2_putc(Uint8 mes)
	{
		while(BusyUART2());
		putcUART2(mes);	
	}
#endif /* def USE_UART2 */



//	Determination de la vitesse de l'uart en fonction
//	de la PLL utilis�e
	#ifdef FREQ_10MHZ
		#define UART_SPEED 64
	#elif (defined FREQ_20MHZ)
		#define UART_SPEED 128
	#elif (defined FREQ_40MHZ)
		#define UART_SPEED 256
	#endif
	/* A 10MHz de freq interne Vitesse 16 -> 38400bps 64-> 9600*/
 
//	Fin de determination de la vitesse.



/*	fonction initialisant les uart choisis
	vitesse : 9600 bauds
	bits de donnees : 8
	parite : aucune
	bit de stop : 1
	pas de controle de flux
*/
void UART_init(void)
{
	Sint16 U1MODEvalue;
	Sint16 U1STAvalue;
	U1MODEvalue = UART_EN & UART_IDLE_CON &
		UART_DIS_WAKE & UART_DIS_LOOPBACK &
		UART_DIS_ABAUD & UART_NO_PAR_8BIT &
		UART_1STOPBIT;
	U1STAvalue = UART_INT_TX &
		UART_TX_PIN_NORMAL &
		UART_TX_ENABLE &
		UART_INT_RX_CHAR &
		UART_ADR_DETECT_DIS &
		UART_RX_OVERRUN_CLEAR ;

	#ifdef USE_UART1
		OpenUART1(U1MODEvalue, U1STAvalue, UART_SPEED);
		#ifndef USE_UART1RXINTERRUPT
			DisableIntU1RX;
		#endif /* ndef USE_UART1RXINTERRUPT */
		DisableIntU1TX;
		ConfigIntUART1(UART_RX_INT_EN & UART_RX_INT_PR4 &
			UART_TX_INT_DIS & UART_TX_INT_PR3);
	#endif /* def USE_UART1 */

	#ifdef USE_UART2
		OpenUART2(U1MODEvalue, U1STAvalue, UART_SPEED);
		#ifndef USE_UART2RXINTERRUPT
			DisableIntU2RX;
		#endif /* ndef USE_UART2RXINTERRUPT */
		DisableIntU2TX;
		ConfigIntUART2(UART_RX_INT_EN & UART_RX_INT_PR4 &
			UART_TX_INT_DIS & UART_TX_INT_PR3);
	#endif /* def USE_UART2 */
}


#ifdef USE_UART1RXINTERRUPT
	void _ISR _U1RXInterrupt(void)
	{
		Uint8 * receiveddata = global.u1rxbuf;
		
		while( DataRdyUART1())
		{
			*(receiveddata++) = ReadUART1();
	
			/* pour eviter les comportements ind�sirables */
			if (receiveddata - global.u1rxbuf >= UART_RX_BUF_SIZE)
				receiveddata = global.u1rxbuf;
		}
		IFS0bits.U1RXIF = 0;
	}
#endif /* def USE_UART1RXINTERRUPT */


#ifdef USE_UART2RXINTERRUPT
	void _ISR _U2RXInterrupt(void)
	{
		Uint8 * receiveddata = global.u2rxbuf;
		
		while( DataRdyUART2())
		{
			*(receiveddata++) = ReadUART2();
	
			/* pour eviter les comportements ind�sirables */
			if (receiveddata - global.u2rxbuf >= UART_RX_BUF_SIZE)
				receiveddata = global.u2rxbuf;
		}
		IFS0bits.U2RXIF = 0;
	}
#endif /* def USE_UART2RXINTERRUPT */
