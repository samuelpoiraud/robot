/*
 *  Club Robot ESEO 2008 - 2009
 *  Archi-Tech'
 *
 *  Fichier : QS_global_vars.h
 *  Package : Qualit� Soft
 *  Description : Variables globales generiques communes a tous les
 *					codes du robot.
 *  Auteur : Jacen
 *  Version 20081010
 */

#ifndef QS_GLOBAL_VARS_H
	#define QS_GLOBAL_VARS_H
	
	#include "../QS/QS_all.h"


	typedef struct
	{
		#ifdef USE_UART1RXINTERRUPT
			volatile bool_e u1rx;	// message re�u sur uart1
		#endif /* def USE_UART1RXINTERRUPT */
		#ifdef USE_UART2RXINTERRUPT
			volatile bool_e u2rx;	// message re�u sur uart2
		#endif /* def USE_UART2RXINTERRUPT */
		#ifdef USE_CAN
			volatile bool_e canrx;	// message re�u sur le bus can
		#endif /* def USE_CAN */
		#ifdef USE_CAN2
			volatile bool_e can2rx;	// message re�u sur le bus can2
		#endif /* def USE_CAN2 */
		
		/* INSERTION DES FLAGS UTILISATEUR */
		#include "../project/Global_flags.h"

	} flag_list_t;



	typedef struct
	{
		#ifdef USE_UART1RXINTERRUPT
			Uint8 u1rxbuf[UART_RX_BUF_SIZE];
		#endif /* def USE_UART1RXINTERRUPT */
		#ifdef USE_UART2RXINTERRUPT
			Uint8 u2rxbuf[UART_RX_BUF_SIZE];
		#endif /* def USE_UART2RXINTERRUPT */
		#ifdef USE_CAN
			CAN_msg_t can_buffer[CAN_BUF_SIZE];
			volatile Uint16 can_rx_num;
		#endif /* def USE_CAN */
		#ifdef USE_CAN2
			CAN_msg_t can2_buffer[CAN_BUF_SIZE];
			volatile Uint16 can2_rx_num;
		#endif /* def USE_CAN2 */
		volatile flag_list_t flags;

		/* INSERTION DES VARIABLES GLOBALES UTILISATEUR */
		#include "../project/Global_vars.h"	
	} global_data_storage_t;

	#ifndef QS_GLOBAL_VARS_C
		extern global_data_storage_t global;
	#endif /* ndef QS_GLOBAL_VARS_C */
#endif /* ndef QS_GLOBAL_VARS_H */
