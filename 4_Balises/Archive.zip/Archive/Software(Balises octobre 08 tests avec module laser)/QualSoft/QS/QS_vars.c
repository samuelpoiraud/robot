/*
 *  Club Robot ESEO 2008 - 2009
 *  Archi-Tech'
 *
 *  Fichier : QS_config.c
 *  Package : Qualit� Soft
 *  Description : declaration de la structure contenant les
 *					variables globales
 *  Auteur : Jacen (inspir� du package QS d'Axel Voitier)
 *  Version 20081010
 */

#define QS_GLOBAL_VARS_C

#include "QS_global_vars.h"

global_data_storage_t global;










