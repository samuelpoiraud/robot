/*
 *  Club Robot ESEO 2008 - 2009
 *  Archi-Tech'
 *
 *  Fichier : QS_timer.h
 *  Package : Qualit� Soft
 *  Description : Gestion et configuration des timer
 *  Auteur : Jacen
 *  Version 20081023
 */

#define QS_TIMER_C

#include "QS_timer.h"


void TIMER_init()
{
	/* les interruptions sont activ�es au lancement du timer */
	ConfigIntTimer1(T1_INT_PRIOR_4 & T1_INT_OFF);
	ConfigIntTimer2(T2_INT_PRIOR_4 & T2_INT_OFF);
	ConfigIntTimer3(T3_INT_PRIOR_4 & T3_INT_OFF);
	ConfigIntTimer45(T5_INT_PRIOR_4 & T5_INT_OFF);
	/* Timer45 est un timer 32 bits compos� des timers 4 et 5 */
}

void TIMER1_stop(void)
{	
	DisableIntT1;
	WriteTimer1(0);
	CloseTimer1();
}

void TIMER1_run(Uint8 period /* en millisecondes */)
{	
	OpenTimer1(
			T1_ON &					/* Timer1 ON */ 
			T1_IDLE_CON &			/* operate during sleep */
			T1_GATE_OFF &			/* Timer Gate time accumulation disabled */
			T1_PS_1_256 &			/* Prescaler 1:256 */
			T1_SYNC_EXT_OFF &		/* Do not synch external clk input */
			T1_SOURCE_INT,			/* Internal clock source */
			PULSE_PER_MS * period);	/* periode en ms */
	EnableIntT1;
}

void TIMER2_stop(void)
{	
	DisableIntT2;
	WriteTimer2(0);
	CloseTimer2();
}

void TIMER2_run(Uint8 period /* en millisecondes */)
{
	OpenTimer2(
			T2_ON &					/* Timer2 ON */ 
			T2_IDLE_CON &			/* operate during sleep */
			T2_GATE_OFF &			/* Timer Gate time accumulation disabled */
			T2_PS_1_256 &			/* Prescaler 1:256 */
			T2_32BIT_MODE_OFF &		/* Timer 2 and Timer 3 form are 2 16 bit Timers */
			T2_SOURCE_INT,			/* Internal clock source */
			PULSE_PER_MS * period);	/* periode en ms */
	EnableIntT2;
}

void TIMER3_stop(void)
{	
	DisableIntT3;
	WriteTimer3(0);
	CloseTimer3();
}

void TIMER3_run(Uint8 period /* en millisecondes */)
{
	OpenTimer3(
			T3_ON &					/* Timer3 ON */ 
			T3_IDLE_CON &			/* operate during sleep */
			T3_GATE_OFF &			/* Timer Gate time accumulation disabled */
			T3_PS_1_256 &			/* Prescaler 1:256 */
			T3_SOURCE_INT,			/* Internal clock source */
			PULSE_PER_MS * period);	/* periode en ms */
	EnableIntT3;
}

void TIMER3_run_us(Uint16 period /* en �s */)
{
	OpenTimer3(
			T3_ON &					/* Timer3 ON */ 
			T3_IDLE_CON &			/* operate during sleep */
			T3_GATE_OFF &			/* Timer Gate time accumulation disabled */
			T3_PS_1_1 &				/* Prescaler 1:1 */
			T3_SOURCE_INT,			/* Internal clock source */
			PULSE_PER_US * period);	/* periode en �s */
	EnableIntT3;
}
/*	note sur TIMER3_run_us :
 *	la periode du timer ne peut pas d�passer
 *	6553 �s � 10 MHz
 *	3276 �s � 20 MHz
 *	1638 �s � 40 MHz
 */

void TIMER4_stop(void)
{	
	/* Il s'agit en fait de la combinaison des Timers 4 et 5 */
	DisableIntT5;
	WriteTimer45(0);
	CloseTimer45();
}

void TIMER4_run(Uint16 period /* en millisecondes */)
{
	/* Il s'agit en fait de la combinaison des Timers 4 et 5 */
	OpenTimer4(
			T4_ON &					/* Timer4 ON */ 
			T4_IDLE_CON &			/* operate during sleep */
			T4_GATE_OFF &			/* Timer Gate time accumulation disabled */
			T4_PS_1_256 &			/* Prescaler 1:256 */
			T4_SOURCE_INT &			/* Internal clock source */
			T4_32BIT_MODE_OFF,		/* Timer 4 and Timer 5 form a 32 bit Timer */
			PULSE_PER_MS * period);	/* periode en ms */
	EnableIntT5;
}
