/*
 *	Club Robot ESEO 2008 - 2009
 *	Archi-Tech'
 *
 *	Fichier : QS_all.h
 *	Package : Qualite Soft
 *	Description : Header necessaire pour tout code du robot
 *	Auteur : Jacen
 *	Version 20081010
 */

#ifndef QS_ALL_H
	#define QS_ALL_H

	#include "../project/Global_config.h"	/*	On charge d'abord la configuration globale		*/
	#include "QS_configCheck.h"				/*	On verifie que le programmeur a selectionn� les	*/
											/*	elements indispensables 						*/

	#include "p30f6010a.h"					/* 	Toujours utile...								*/

	#include "QS_configBits.h"				/*	configuration interne du pic ajout�e dans le	*/
											/*	fichier definissant QS_GLOBAL_VARS_C 			*/

	#include "QS_types.h"					/*	Nos types										*/
	#include "QS_macro.h"					/*	quelques macro pratiques						*/
	#include "QS_global_vars.h"				/*	Les variables globales (notamment les drapeaux) */


#endif /* ndef QS_ALL_H */
