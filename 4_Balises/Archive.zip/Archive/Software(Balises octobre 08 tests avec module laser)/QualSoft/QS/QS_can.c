/*
 *  Club Robot ESEO 2006 - 2009
 *  Game Hoover - Archi-Tech'
 *
 *  Fichier : QS_can.c
 *  Package : Qualit� Soft
 *  Description : fonction CAN
 *  Auteur : Kim (2006-2007, modifi� par Jacen(2006-2009) 
 *  Version 20081012
 */

#define QS_CAN_C

#include "QS_can.h"
#if defined (USE_CAN) || defined (USE_CAN2)
	
	void CAN_init(void)
	{
		#ifdef USE_CAN
			C1INTF=0;
			IFS1bits.C1IF=0;
			CAN1SetOperationMode(CAN_IDLE_CON &
				CAN_MASTERCLOCK_1 &
				CAN_REQ_OPERMODE_CONFIG &
				CAN_CAPTURE_DIS);
			CAN1Initialize(CAN_SYNC_JUMP_WIDTH1 &
				CAN_BAUD_PRE_SCALE(2),
				CAN_WAKEUP_BY_FILTER_DIS &
				CAN_PHASE_SEG2_TQ(3) &
				CAN_PHASE_SEG1_TQ(3) &
				CAN_PROPAGATIONTIME_SEG_TQ(3) &
				CAN_SEG2_FREE_PROG &
				CAN_SAMPLE3TIMES);
			ConfigIntCAN1(CAN_INDI_INVMESS_DIS &
				CAN_INDI_WAK_DIS &
				CAN_INDI_ERR_DIS &
				CAN_INDI_TXB2_DIS &
				CAN_INDI_TXB1_DIS &
				CAN_INDI_TXB0_DIS &
				CAN_INDI_RXB1_EN &
				CAN_INDI_RXB0_EN ,
				CAN_INT_PRI_3 &
				CAN_INT_ENABLE);
		
			C1INTF=0;
			IFS1bits.C1IF=0;
		
			CAN1SetMask(0, CAN_MASK_SID(MASK_CAN_S) & CAN_MATCH_FILTER_TYPE, CAN_MASK_EID(3));
		
			CAN1SetRXMode(0,CAN_RXFUL_CLEAR & CAN_BUF0_DBLBUFFER_EN);
			CAN1SetRXMode(1,CAN_RXFUL_CLEAR & CAN_BUF0_DBLBUFFER_EN);
			CAN1SetTXMode(0,CAN_TX_STOP_REQ & CAN_TX_PRIORITY_HIGH );
			CAN1SetTXMode(1,CAN_TX_STOP_REQ & CAN_TX_PRIORITY_HIGH );
			CAN1SetTXMode(2,CAN_TX_STOP_REQ & CAN_TX_PRIORITY_HIGH );
		
			CAN1SetOperationMode(CAN_IDLE_CON & CAN_MASTERCLOCK_1 & CAN_REQ_OPERMODE_NOR & CAN_CAPTURE_DIS);
			/* initialisation du buffer de reception des messages CAN */
			global.can_rx_num =CAN_BUF_SIZE -1;
		#endif /* def USE_CAN */

		#ifdef USE_CAN2
			C2INTF=0;
			IFS1bits.C2IF=0;
			CAN2SetOperationMode(CAN_IDLE_CON &
				CAN_MASTERCLOCK_1 &
				CAN_REQ_OPERMODE_CONFIG &
				CAN_CAPTURE_DIS);
			CAN2Initialize(CAN_SYNC_JUMP_WIDTH1 &
				CAN_BAUD_PRE_SCALE(2),
				CAN_WAKEUP_BY_FILTER_DIS &
				CAN_PHASE_SEG2_TQ(3) &
				CAN_PHASE_SEG1_TQ(3) &
				CAN_PROPAGATIONTIME_SEG_TQ(3) &
				CAN_SEG2_FREE_PROG &
				CAN_SAMPLE3TIMES);
			ConfigIntCAN2(CAN_INDI_INVMESS_DIS &
				CAN_INDI_WAK_DIS &
				CAN_INDI_ERR_DIS &
				CAN_INDI_TXB2_DIS &
				CAN_INDI_TXB1_DIS &
				CAN_INDI_TXB0_DIS &
				CAN_INDI_RXB1_EN &
				CAN_INDI_RXB0_EN ,
				CAN_INT_PRI_3 &
				CAN_INT_ENABLE);
		
			C2INTF=0;
			IFS1bits.C2IF=0;
		
			CAN2SetMask(0, CAN_MASK_SID(MASK_CAN_S) & CAN_MATCH_FILTER_TYPE, CAN_MASK_EID(3));
		
			CAN2SetRXMode(0,CAN_RXFUL_CLEAR & CAN_BUF0_DBLBUFFER_EN);
			CAN2SetRXMode(1,CAN_RXFUL_CLEAR & CAN_BUF0_DBLBUFFER_EN);
			CAN2SetTXMode(0,CAN_TX_STOP_REQ & CAN_TX_PRIORITY_HIGH );
			CAN2SetTXMode(1,CAN_TX_STOP_REQ & CAN_TX_PRIORITY_HIGH );
			CAN2SetTXMode(2,CAN_TX_STOP_REQ & CAN_TX_PRIORITY_HIGH );
		
			CAN2SetOperationMode(CAN_IDLE_CON & CAN_MASTERCLOCK_1 & CAN_REQ_OPERMODE_NOR & CAN_CAPTURE_DIS);
			/* initialisation du buffer de reception des messages CAN */
			global.can2_rx_num =CAN_BUF_SIZE -1;

		#endif /* def USE_CAN2 */
	}
	
	void CAN_send(CAN_msg_t* can_msg)
	{
		while(!CAN1IsTXReady(0));	
		CAN1SendMessage((CAN_TX_SID(can_msg->sid)) & (CAN_TX_EID_DIS) & (CAN_SUB_NOR_TX_REQ),
						(CAN_TX_EID(12344)) & (CAN_NOR_TX_REQ),can_msg->data, can_msg->taille, 0);
	
	}
	
	void CAN_receive(CAN_msg_t* can_msg)
	{
		if(C1RX0CONbits.RXFUL==1)
		{
			/* r�ception d'un message dans le buffer RX0 */
			can_msg->sid=C1RX0SID>>2;
			can_msg->taille=C1RX0DLCbits.DLC;
			CAN1ReceiveMessage(can_msg->data,can_msg->taille,0);
			C1RX0CONbits.RXFUL=0;
			C1INTF=0;
		}
		else if(C1RX1CONbits.RXFUL==1)
		{
			/* r�ception d'un message dans le buffer RX1 */
			can_msg->sid=C1RX1SID>>2;
			can_msg->taille=C1RX1DLCbits.DLC;
			CAN1ReceiveMessage(can_msg->data,can_msg->taille,1);
			C1RX1CONbits.RXFUL=0;
			C1INTF=0;
		}
		else 
		{
			can_msg->sid=0;
			can_msg->taille=0;
		}
		return;
	}


	void CAN2_send(CAN_msg_t* can_msg)
	{
		while(!CAN2IsTXReady(0));	
		CAN2SendMessage((CAN_TX_SID(can_msg->sid)) & (CAN_TX_EID_DIS) & (CAN_SUB_NOR_TX_REQ),
						(CAN_TX_EID(12344)) & (CAN_NOR_TX_REQ),can_msg->data, can_msg->taille, 0);

	}


	void CAN2_receive(CAN_msg_t* can_msg)
	{
		if(C2RX0CONbits.RXFUL==1)
		{
			/* r�ception d'un message dans le buffer RX0 */
			can_msg->sid=C2RX0SID>>2;
			can_msg->taille=C2RX0DLCbits.DLC;
			CAN2ReceiveMessage(can_msg->data,can_msg->taille,0);
			C2RX0CONbits.RXFUL=0;
			C2INTF=0;
		}
		else if(C2RX1CONbits.RXFUL==1)
		{
			/* r�ception d'un message dans le buffer RX1 */
			can_msg->sid=C2RX1SID>>2;
			can_msg->taille=C2RX1DLCbits.DLC;
			CAN2ReceiveMessage(can_msg->data,can_msg->taille,1);
			C2RX1CONbits.RXFUL=0;
			C2INTF=0;
		}
		else 
		{
			can_msg->sid=0;
			can_msg->taille=0;
		}
		return;
	}
	
	#ifdef USE_CAN
		void _ISR _C1Interrupt(void)
		{		
			CAN_receive(global.can_buffer + (global.can_rx_num % CAN_BUF_SIZE));	
	
			global.can_rx_num++;
			global.can_rx_num%=CAN_BUF_SIZE;		
	
			/*	Explication de la condition ci dessous :
			 *	Le sid est compos� de 16 bits.
			 *	Les 5 premiers servent � determiner l'emetteur du message
			 *	Les 5 suivants permettent de determiner le ou les destinataires du message
			 *	Les 6 derniers bits servent a identifer le message en lui meme
			 *	Le test & (1<<(6+I_AM)) teste le bit de la carte
					il passe les 6 bits d'id du message, puis avance de l'identifiant de la carte
					qui est conserv� dans I_AM dans Global_config.h
			 *	Ce test ne s'applique pas � la carte supervision
			 */
			#if (I_AM != CARTE_SUPER)
			if((global.can_buffer[global.can_rx_num]).sid & (1<<(6+I_AM)))
			#endif	/* (I_AM != CARTE_SUPER) */
				global.flags.canrx = TRUE;
	
			#if (I_AM != CARTE_SUPER)
			else
				global.can_rx_num = (global.can_rx_num)?global.can_rx_num-1:CAN_BUF_SIZE-1;
			#endif	/* (I_AM != CARTE_SUPER) */

			IFS1bits.C1IF=0;
		}
	#endif /* def USE_CAN */

	#ifdef USE_CAN2
		void _ISR _C2Interrupt(void)
		{		
			CAN_receive(global.can_buffer + (global.can2_rx_num % CAN_BUF_SIZE));	
	
			global.can2_rx_num++;
			global.can2_rx_num%=CAN_BUF_SIZE;		
	
			/*	Explication de la condition ci dessous :
			 *	Le sid est compos� de 16 bits.
			 *	Les 5 premiers servent � determiner l'emetteur du message
			 *	Les 5 suivants permettent de determiner le ou les destinataires du message
			 *	Les 6 derniers bits servent a identifer le message en lui meme
			 *	Le test & (1<<(6+I_AM)) teste le bit de la carte
					il passe les 6 bits d'id du message, puis avance de l'identifiant de la carte
					qui est conserv� dans I_AM dans Global_config.h
			 *	Ce test ne s'applique pas � la carte supervision
			 */
			#if (I_AM != CARTE_SUPER)
			if((global.can2_buffer[global.can2_rx_num]).sid & (1<<(6+I_AM)))
			#endif	/* (I_AM != CARTE_SUPER) */
				global.flags.can2rx = TRUE;
	
			#if (I_AM != CARTE_SUPER)
			else
				global.can2_rx_num = (global.can2_rx_num)?global.can2_rx_num-1:CAN_BUF_SIZE-1;
			#endif	/* (I_AM != CARTE_SUPER) */
			IFS1bits.C2IF=0;
		}
	#endif /* def USE_CAN2 */
#endif /* defined (USE_CAN) || defined (USE_CAN2) */
