/*
 *  Club Robot ESEO 2008 - 2009
 *  Archi-Tech'
 *
 *  Fichier : QS_nomenclatureCAN.h
 *  Package : Qualit� Soft
 *  Description : alias des sid des messages CAN
 *  Auteur : Jacen
 *  Version 20080909
 */

#ifndef QS_NOMENCLATURECAN_H
	#define QS_NOMENCLATURECAN_H

	/* Masque des cartes */
	#define MASK_CAN					0x780 /* 0b11110000000 */
  	#define MASK_CAN_S					0x000 /* 0b00000000000 */	
  	#define FILTER_CARTE_P				0x080 /* 0b00010000000 */
  	#define FILTER_CARTE_M				0x180 /* 0b00110000000 */
  	#define FILTER_CARTE_ASSER			0x100 /* 0b00100000000 */
  	#define FILTER_BROADCAST			0x780 /* 0b11110000000 */
	
  	/* Message pour tous */
  	#define BROADCAST_START	 			0x790
  	#define BROADCAST_STOP_ALL 			0x7A0

  	/* Carte asser vers carte P */
  	#define CARTE_P_TRAJ_FINIE			0x081 /* 0b00010000001 */
  	#define CARTE_P_ASSER_ERREUR		0x082 /* 0b00010000010 */
  	#define CARTE_P_POSITION_ROBOT		0x083 /* 0b00010000011 */
  	#define CARTE_P_ROBOT_FREINE		0x084 /* 0b00010000100 */

  	/* Carte P vers carte asser */
  	#define CARTE_ASSER_GO_POSITION		0x101 /* 0b00100000001 */
 	#define CARTE_ASSER_VITESSE			0x102 /* 0b00100000010 */
 	#define CARTE_ASSER_STOP			0x103 /* 0b00100000011 */
  	#define CARTE_ASSER_GO_ANGLE		0x104 /* 0b00100000100 */

  	#define CARTE_ASSER_CONTI_MULTI		0x106 /* 0b00100000110 */
  	#define CARTE_ASSER_STOP_MULTI		0x107 /* 0b00100000111 */
  	#define CARTE_ASSER_COULEUR			0x108 /* 0b00100001000 */
 	#define CARTE_ASSER_POSITION		0x109 /* 0b00100001001 */
  	#define CARTE_ASSER_DEBLOCK      	0x110 /* 0b00100010000 */
  	#define CARTE_ASSER_DEBUG       	0x111 /* 0b00100010001 */

  	/* Message pour tous */
  	#define BROADCAST_START	 			0x790
  	#define BROADCAST_STOP_ALL 			0x7A0

	/*Carte M vers carteP */
	#define CARTEP_OBJET_IN				0x085 /* 0b00010000101 */
	#define CARTEP_PRET_A_TIRER			0x086 /* 0b00010000110 */
	#define CARTEP_SHOOTED				0x087 /* 0b00010000111 */
	#define CARTEP_CAS_A_LA_CON			0x088 /* 0b00010001000 */

	/* Carte P vers Carte M*/
	#define CARTE_M_OUVRE				0x181 /* 0b00110000001 */
	#define CARTE_M_FERME				0x182 /* 0b00110000010 */
	#define CARTE_M_TIRE				0x183 /* 0b00110000011 */
	#define CARTE_M_VITESSE_BRUSHLESS	0x184 /* 0b00110000100 */
	#define CARTE_M_AUTO				0x185 /* Ob00110000101 */

#endif	/* ndef QS_NOMENCLATURECAN_H */