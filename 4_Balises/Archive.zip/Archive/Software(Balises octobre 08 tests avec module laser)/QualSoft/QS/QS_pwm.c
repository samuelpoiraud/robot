/*
 *	Club Robot ESEO 2008 - 2009
 *	Archi-Tech'
 *
 *	Fichier : QS_pwm.c
 *	Package : Qualite Soft
 *	Description : fonction de manipulation des PWM du dsPIC30F6010A
 *					(PWM1H, PWM2H, PWM3H, PWM4H)
 *	Auteur : Jacen, d'apr�s le code d'Emmanuel FRADIN
 *	Version 20081012
 */

 
#define QS_PWM_C

#include "QS_pwm.h"


void PWM_init(void)			/* Initialisation du p�riph�rique PWM */
{
	Uint16 config1, config2, config3;

	/* configuration des quatres canaux pour ceux g�r�s par les g�n�rateurs de PWM */
	config1 = PWM_EN & PWM_IDLE_STOP & PWM_OP_SCALE16 & PWM_IPCLK_SCALE64 & PWM_MOD_FREE;
	config2 = 	PWM_PEN4H & PWM_PEN3H & PWM_PEN2H & PWM_PEN1H & PWM_PEN4L & PWM_PEN3L
				& PWM_PEN2L & PWM_PEN1L & PWM_MOD1_COMP & PWM_MOD2_COMP & PWM_MOD3_COMP 
				& PWM_MOD4_COMP;
	config3 = PWM_SEVOPS1 & PWM_OSYNC_PWM & PWM_UEN;
	OpenMCPWM(DEMI_PERIODE_PWM, 0, config1, config2, config3);
}

void PWM_run(Uint8 duty /* en pourcent */, Uint8 voie)
{
	if (voie && (voie <=4))
	{
		SetDCMCPWM(voie, 20*duty, 0);
	}
}   

void PWM_stop(Uint8 voie)
{
	if (voie && (voie <=4))
		SetDCMCPWM(voie,0,0);
}
