/*
 *	Club Robot ESEO 2008 - 2009
 *	Archi-Tech'
 *
 *	Fichier : Laser.c
 *	Package : Balises
 *	Description : Utilisation du laser dans les balises, gestion des interruptions externes
 *	Auteur : Christophe Sambourg (utilisation de bouts de codes de phoboss 2008)
 *	Version 200810
 */

#define LASER_C

#include "laser.h"


void _ISR _INT0Interrupt(void)
	{

		global.laser_impulsions++;
//		global.moteur_destination = global.moteur_position;
				LED_J=!LED_J;	
		_INT0IF = 0;		/* Acquittement de l'IT */			
	}


void laser_init(void)
	{
		PWM_run(25,1);
		/* Pin INT0 en entr�e */
		_TRISF6 = 1;

		/* Detection des interruptions externes sur front montant*/
	//A RENDRE PLUS PROPRE !!!!!!!!!!!!!!!!
		_INT0EP = 1;
		_INT0IF = 0;
		_INT0IE = 1;
	}



