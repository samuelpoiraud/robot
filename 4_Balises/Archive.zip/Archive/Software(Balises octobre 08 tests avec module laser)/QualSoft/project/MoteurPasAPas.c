/*
 *	Club Robot ESEO 2008 - 2009
 *	Archi-Tech'
 *
 *	Fichier : MoteurPasAPas.c
 *	Package : Balises
 *	Description : Utilisation du moteur pas a pas dans les balises
 *	Auteur : Christophe Sambourg (utilisation de bouts de codes de phoboss 2008)
 *	Version 200810
 */

#define MOTEUR_PAS_A_PAS_C

#include "MoteurPasAPas.h"


void _ISR _T3Interrupt(void)
	{
		
		global.flags.timer3=1;
		moteur_changer_pas();
		//moteur_test_rotation_continue();


		
	//	TMR1 = 0x0000;	/* Remise � z�ro du timer */
		_T3IF = 0;		/* Acquittement de l'IT */			
	}


void moteur_init(void)
	{
		TRISB = TRISB & 0xFF03;		/* Configuration du port */
		MOTEUR_ENABLEA = 0;
		MOTEUR_ENABLEB = 0;
		global.moteur_position = 0x0000;
		global.moteur_sens = 0x00;
		global.moteur_destination = 0x0000;
	}



void moteur_test_rotation_continue(void)
{
		moteur_pas = (moteur_pas+1) % 8;
		PORT_MOTEUR	= moteur_commandes[moteur_pas];
		//les 8 premiers bits sont en entr�es
		/*les deux suivants sont les enables 
			> d'o� la s�quence dans MoteurPasAPas.h 
		qui est de la forme 0b 0000 0000 11xx xx00
		xx xx sont les bits de commande du pont en H...
		*/
}


void moteur_changer_pas(void)
{

	if(global.moteur_sens)
	{
		global.moteur_position++;
		moteur_pas = (moteur_pas+1) % 8;
	}
	else
	{
		global.moteur_position--;
		moteur_pas = (moteur_pas-1) % 8;
	}

	PORT_MOTEUR	= moteur_commandes[moteur_pas];
}

