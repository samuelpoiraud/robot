/*
 *	Club Robot ESEO 2008 - 2009
 *	Archi-Tech'
 *
 *	Fichier : MoteurPasAPas.h
 *	Package : Balises
 *	Description : Utilisation du moteur pas a pas dans les balises
 *	Auteur : Christophe Sambourg (utilisation de bouts de codes de phoboss 2008)
 *	Version 200810
 */
 
#ifndef MOTEUR_PAS_A_PAS_H
	#define MOTEUR_PAS_A_PAS_H
	#include "../QS/QS_all.h"
		
	#define MOTEUR_BUTEE_SUPERIEURE 50
	#define MOTEUR_BUTEE_INFERIEURE -50


	void _ISR _T1Interrupt(void);
	void moteur_init(void);
	void moteur_test_rotation_continue(void);
	void moteur_changer_pas(void);
	

	#ifdef MOTEUR_PAS_A_PAS_C
		
	Uint8 moteur_commandes[8]={0x00E0, 0x00E8, 0x00C8, 0x00D8, 0x00D0, 0x00D4, 0x00C4, 0x00E4};
	Uint8 moteur_pas;	//num�ro du pas en cours (entre 0 et 8...)


	#endif /* def MOTEUR_PAS_A_PAS_C */
#endif /* ndef MOTEUR_PAS_A_PAS_H */
