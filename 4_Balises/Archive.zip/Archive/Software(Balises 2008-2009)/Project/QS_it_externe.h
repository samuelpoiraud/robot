/*
 *	Club Robot ESEO 2008 - 2009
 *	Archi'Tech
 *
 *	Fichier : QS_pwm.h
 *	Package : Qualite Soft
 *	Description : fonction d'utilisation des "IT Externe" dsPIC30F6010A
 *					(INT0, INT1, INT2, INT3)
 *	Auteur : Nirgal
 *	Version 20090131
 */
 
#ifndef QS_IT_EXTERNE_H
	#define QS_IT_EXTERNE_H
	#include "..\QS\QS_all.h"
	
	typedef enum 
	{
		INT0,INT1,INT2,INT3
	} IT_e;
			
	void IT_Externe_Enable(IT_e Channel, bool_e front);
	//Front : 1 pour front descendant, 0 pour front montant
	//Channel : INT0, INT1, INT2 ou INT3...
		
	void IT_Externe_Disable(IT_e Channel);
			
	void IT_Externe_Acknowledge(IT_e Channel);
	
	
	
	/*Fonctions appel�es sur Interruptions...
	
	INT0 : void _ISR _INT0Interrupt(void)
	INT1 : void _ISR _INT1Interrupt(void)
	INT2 : void _ISR _INT2Interrupt(void)
	INT3 : void _ISR _INT3Interrupt(void)
	
	
	*/
	
	
	
	#ifdef QS_IT_EXTERNE_C








	#endif /* def QS_IT_EXTERNE_C */
#endif /* ndef QS_IT_EXTERNE_H */
