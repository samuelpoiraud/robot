/*
 *	Club Robot ESEO 2008 - 2009
 *	Archi'Tech
 *
 *	Fichier : Tableau.h
 *	Package : Balises
 *	Description : tableaux et fonctions permettant le calcul de la position
 *   				du robot adverse selon les angles mesur�s
 *	Auteur : Nirgal
 *	Version 20090210
 */
 
 #ifndef TABLEAU_H
	#define TABLEAU_H
	#include "..\QS\QS_all.h"
	
	Sint16 find_x(Sint16 a, Sint16 b);
	Sint16 find_y(Sint16 a, Sint16 b);
	
	#ifdef TABLEAU_C
		//variables priv�es
		const Sint16 __attribute__ ((space(psv))) tableau_x [127][127];
		const Sint16 __attribute__ ((space(psv))) tableau_y [127][127];
		Sint16 retour;
	#endif /*def TABLEAU_C*/
	
	
	
	#ifdef TABLEAU_C








	#endif /* def TABLEAU_C */
#endif /* ndef TABLEAU_H */
