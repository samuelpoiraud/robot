/*
 *	Club Robot ESEO 2008 - 2009
 *	Archi-Tech'
 *
 *	Fichier : Test_main.c
 *	Package : Carte Balises
 *	Description : fonction principale permettant
 *				l'appel des fonctions de test de la carte balise
 *	Auteur : Christophe
 *	Version 20081209
 */

#define TEST_MAIN_C
#include "Test_main.h"
#ifdef TEST_MODE


	
	
	
	
	void initialisation (void)
	{

		PORTS_init();
		//ADC_init();
		TIMER_init();
		UART_init();  // ATTENTION : n'activez l'uart que si vous branchez le cable, sinon risque de blocage !	
		Beacon_init();
	}
	
	void tests(void)
	{
		#ifdef TEST_MODE
			debug_printf("Balise still alive !\n");
		#endif
	}	


	int main (void)
	{
		
		initialisation();
		tests();
		
		while (1)
		{
//			printf("\n,%d,\n,",TMR1);
			process_beacon();
			
			//Si on a recu un caract�re venant de l'uart...
			if(global.flags.u2rx)
				process_u2rx();
	
			//S'il est temps d'envoyer les donn�es ou si l'on a recu une donn�e � envoyer... on envoi !
			if(global.flags.timer2 == TRUE || global.flag_envoi == TRUE)
				process_envoi();
				
			if(global.flags.timer1 == TRUE)
			{
				global.flags.timer1 = FALSE;
				debug_printf("Timer1, erreur d�tection\n");	
			}	
			
			//Si une IT s'est d�clench�e depuis le dernier passage dans la boucle de main...
//			if(global.flags.it)
//				process_it();


			if(global.flags.timer2 == TRUE)
			{
				global.flags.timer2 = FALSE;
				static Uint8 i, balise, j;
				i = (i + 1) %4;
			/*	if(!i)
					for(balise=0;balise<3;balise++)
						for(j=0;j<NOMBRE_DETECTIONS_PAR_BALISE;j++)	
							debug_printf("b%d\td%d:\t%d\t%d\n",balise,j, detections[balise][j].debut,detections[balise][j].fin);	
			*/
			/*
				if(!i)
					for(balise=0;balise<3;balise++)
						for(j=0;j<NOMBRE_CYCLES_SAUVES;j++)	
							debug_printf("b%d\tc%d:\ti%d\n",balise,j, global.buffer_instants[balise][j]);
			*/				
			}	
		}
		
		return 0;		
	}


#endif /* def TEST_MODE */
