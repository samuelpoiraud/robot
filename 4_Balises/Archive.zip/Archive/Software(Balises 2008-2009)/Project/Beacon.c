/*
 *	Club Robot ESEO 2008 - 2009
 *	Archi'Tech
 *
 *	Fichier : Beacon.c
 *	Package : Balises
 *	Description : Fonctions d'exploitation des balises - code �x�cut� en tache de fond
 *	Auteur : Nirgal
 *	Version 200910
 */

 
#define BEACON_C

#include "Beacon.h"
		



void Beacon_init(void)
{
		initialiser_instants_detections_balises();
		initialiser_detections();
		global.flag_nouveau_cycle = FALSE;	

		global.flag_envoi = FALSE;

		global.color = 0;
		
		global.current_x = 0;
		global.current_y = 0;
		global.valeur_a_envoyer_x = 0;
		global.valeur_a_envoyer_y = 0;


		TIMER1_run(200);
		TIMER2_run(250);	//timer d'envoi vers carte P...
		IT_Externe_Enable(INT1,1);
		IT_Externe_Enable(INT2,1);
		IT_Externe_Enable(INT3,1);
}

	void initialiser_instants_detections_balises(void)	
	{
		Uint8 balise, cycle;
		for(balise = 0;balise<NOMBRE_BALISES;balise++)
			for(cycle = 0;cycle<NOMBRE_CYCLES_SAUVES;cycle++)
				global.buffer_instants[balise][cycle] = 0;
		global.index_cycle = 0;
	}
	
	
	bool_e test_moyenne_xy(void)
	{
		static Sint32 x,y;
		static Uint8 i;
		
		i = (i + 1) % 16;
		x += global.current_x;
		y += global.current_y;
		if(!i)
		{
			x/=160;
			y/=160;
			debug_printf("x:%d,y:%d\n",(Sint16)x,(Sint16)y);
			x = 0;
			y = 0;
		}	
		
		if(!i)
			return TRUE;
		else
			return FALSE;
	}
	
		
	
	void process_beacon(void)
	{
		bool_e valid = TRUE;
		
		//cette fonction, ex�cut�e tr�s r�guli�rement en tache de fond, 
		// r�alise les calculs n�cessaire � l'issu de chaque cycle !
		if(global.flag_nouveau_cycle == TRUE)
		{
			//un nouveau cycle est apparu.
			global.flag_nouveau_cycle = FALSE;
			
			//calcul des angles d'apr�s les mesures brutes
			calcul_angles();
				//debug_printf("a:%d,b:%d\n",(Uint8)global.angles[0],(Uint8)global.angles[2]);
			
			valid &= detection_erreur_angles();
			
			//calculs des coordonn�es xy
			calcul_xy();
				//debug_printf("x:%d,y:%d\n",global.current_x,global.current_y);
			
			valid &= detection_erreur_xy();
				
			valid &= test_moyenne_xy();
			
			if(valid == TRUE)
				global.flag_envoi = TRUE;
		}		
	}

	volatile Uint32 moyenne_instants[3], duree_cycle_moyen;
	
	void calcul_angles(void)
	{
		
		//moyenne instant contiendra la somme des instants de d�tection sur tout les cycles m�moris�s....
		//comme un moyenne sans division.
		//La dur�e du cycle moyen est la somme des dur�es enregistr�es.
		
		
		Uint8 icycle, balise;
		//Calcul de la dur�e moyenne des cycles... (combien fait un tour moteur !)
		duree_cycle_moyen = 0;
		for(icycle=0;icycle<NOMBRE_CYCLES_SAUVES;icycle++)
			duree_cycle_moyen += (Uint32)(global.buffer_instants[NOMBRE_BALISES][icycle]);
		//ATTENTION, cette moyenne est faite sans la division...
//		debug_printf("duree_cycle %li\n",duree_cycle_moyen);
		//TODO peut etre faudrait il plutot faire des m�diannes ???		
		
		for(balise = 0;balise < NOMBRE_BALISES;balise++)
		{
			moyenne_instants[balise] = 0;
			for(icycle=0;icycle<NOMBRE_CYCLES_SAUVES;icycle++)
				moyenne_instants[balise] += (Uint32)(global.buffer_instants[balise][icycle]);

			//ATTENTION, cette moyenne est faite sans la division par le nombre de valeurs..
			//il est important faire le *128 avant la division par la dur�e du cycle !
		}
		//TODO d�tection d'erreur......
		//TODO IMPORTANT : si l'une des valeur est -1, ne pas la prendre en compte, si toutes les valeurs sont -1, ERREUR !!!

		global.angles[0] = (Uint8)(((moyenne_instants[1] - moyenne_instants[0])*128)/duree_cycle_moyen);
		global.angles[1] = (Uint8)(((moyenne_instants[2] - moyenne_instants[1])*128)/duree_cycle_moyen);
		global.angles[2] = (Uint8)128 - global.angles[0] - global.angles[1];
//		debug_printf("moyenne instant 1 %li\n",moyenne_instants[1]);
//		debug_printf("moyenne instant 2 %li\n",moyenne_instants[2]);
//		debug_printf("moyenne instant 0 %li\n",moyenne_instants[0]);
//		debug_printf("duree_cycle %d\n",(int)duree_cycle_moyen);
	}	
		
		
	bool_e detection_erreur_angles(void)
	{
		//	if(global.angles[0] > )
		//TODO !!!!
	
		return TRUE;
	}
	
		
	void calcul_xy(void)
	{
		global.current_x = find_x(global.angles[2],global.angles[0]);
		global.current_y = find_y(global.angles[2],global.angles[0]);
	}
	
	
	bool_e detection_erreur_xy(void)
	{
		
		if(global.current_x > 3500)
			return FALSE;
		if(global.current_y > 2500)
			return FALSE;
		if(global.current_x < -500)
			return FALSE;	
		if(global.current_y < -500)
			return FALSE;
			
				
		return TRUE;
	}

	
void process_u2rx(void)
{
	//on a recu un octet UART
	//on lance la routine de desencapsulation des messages CAN
	if(u2rxToCANmsg((CAN_msg_t *)&(global.CAN_msg)))
	{
		//arriv� ici on a un message CAN stock� dans CAN_msg
		switch(global.CAN_msg.sid)
		{
			case BROADCAST_COULEUR:
				global.color = global.CAN_msg.data[0];
			break;
			default:
			//Ce message ne nous �tait pas destin�
			break;
		}
	}	
		
}

	
void process_envoi(void)
{
		
	global.flags.timer2=0; //Flag timer envoi carte P.

	global.flag_envoi = FALSE;


	if(global.color==0)   // si nous sommes de couleur verte
	{
		global.valeur_a_envoyer_x = global.current_x;//global.Medx[9];
		global.valeur_a_envoyer_y = global.current_y;//global.Medy[9];
	}
	else
	{	// si nous sommes de couleur rouge
		global.valeur_a_envoyer_x = global.current_x - 2100;//global.Medx[9]-2100;
		global.valeur_a_envoyer_y = global.current_y - 3000;//global.Medy[9]-3000;					
	}

	global.other_can_msg.sid=BEACON_POS;
	global.other_can_msg.data[0] = (Uint8)(global.valeur_a_envoyer_x>>8);
	global.other_can_msg.data[1] = (Uint8)(global.valeur_a_envoyer_x);
	global.other_can_msg.data[2] = (Uint8)(global.valeur_a_envoyer_y>>8);
	global.other_can_msg.data[3] = (Uint8)(global.valeur_a_envoyer_y);
	global.other_can_msg.size = 4;

	#ifdef ENVOYER_SUR_UART2_COMME_MSG_CAN
		CANmsgToU2tx((CAN_msg_t *)&(global.other_can_msg));
	#endif
	//Attention, ceci n'est pas forc�ment un debug_printf.. c'est l'usage normal du code balise qui envoie des donn�es sur uart !
	#ifdef ENVOYER_SUR_UART1
		printf("x:%d ",global.valeur_a_envoyer_x);
		printf("y:%d\n",global.valeur_a_envoyer_y);
	#endif			
}

/*	
void process_it(void)
{
	global.flags.it = FALSE;
	//Une valeur trouv�e, mise a jour de la somme et des angles...
	global.somme = global.temps12 + global.temps23 + global.temps31;
	if(global.somme) //Eviter les divisions par 0 !!!
	{
		//	debug_printf("somme:%d\n ",global.somme);
		if(global.somme<3500)
		{
			global.angle_a = (Sint16)(((Sint32)global.temps31)*128/global.somme);
			global.angle_b = (Sint16)(((Sint32)global.temps12)*128/global.somme);
						
								
			global.current_x = find_x(global.angle_a,global.angle_b);
			global.current_y = find_y(global.angle_a,global.angle_b);
						
			
			if(global.compteur_precision < TAILLE_TABLEAU_BUBBLE_SORT) 
			{		
				global.tabx[global.compteur_precision] = global.current_x;	
				global.taby[global.compteur_precision] = global.current_y;
		
				global.moy_x=0;
				global.moy_y=0;
				for(global.i=0; global.i < TAILLE_TABLEAU_BUBBLE_SORT; global.i++)
				{
					global.Medx[global.i] = global.tabx[global.i];
				 	global.Medy[global.i] = global.taby[global.i];
				}
								
				bubblesort();
				#ifdef AFFICHER_POINT_DU_BUBBLE_DE_TEMPS_EN_TEMPS
				
					static Uint16 compteur_nombre_de_passages;
					compteur_nombre_de_passages++;
					if(compteur_nombre_de_passages > 200)
					{
						IT_Externe_Disable(INT1);
						IT_Externe_Disable(INT2);
						IT_Externe_Disable(INT3);
						printf("sum %ld\n",global.somme);
						compteur_nombre_de_passages = 0;
						for(global.i=0; global.i < TAILLE_TABLEAU_BUBBLE_SORT; global.i++)
						{
							debug_printf("x%d:%d ",global.i,global.Medx[global.i]/10);
						 	debug_printf("y%d:%d\n ",global.i,global.Medy[global.i]/10);
						}
						IT_Externe_Enable(INT1,1);
						IT_Externe_Enable(INT2,1);
						IT_Externe_Enable(INT3,1);
					}	
				#endif							
				global.compteur_precision++;
			}
						
							
			if (global.compteur_precision >= TAILLE_TABLEAU_BUBBLE_SORT)  
				global.compteur_precision = 0;
			
		}
	}
}
*/


/*	
	void initialiser bubblesort
	{
		//		int i;
		for(i=0;i<TAILLE_TABLEAU_BUBBLE_SORT;i++)
		{
			global.tabx[i]=0;
			global.taby[i]=0;
			global.Medx[i]=0;
			global.Medy[i]=0;
		}
		
		}


	void bubblesort(void)
	{
		Uint16 i;
		bool_e flag_bubble;
		Sint16 temp;
		do
		{
			flag_bubble = FALSE;
			for(i=1;i<TAILLE_TABLEAU_BUBBLE_SORT;i++)
			{
				if(global.Medx[i-1]<global.Medx[i])
				{
					temp = global.Medx[i-1];
					global.Medx[i-1] = global.Medx[i];
					global.Medx[i] = temp;
					flag_bubble = TRUE;
				}	
			}		
		}while(flag_bubble==TRUE);
		
		do
		{
			flag_bubble = FALSE;
			for(i=1;i<TAILLE_TABLEAU_BUBBLE_SORT;i++)
			{
				if(global.Medy[i-1]<global.Medy[i])
				{
					temp = global.Medy[i-1];
					global.Medy[i-1] = global.Medy[i];
					global.Medy[i] = temp;
					flag_bubble = TRUE;
				}	
			}		
		}while(flag_bubble==TRUE);		
	}

*/


