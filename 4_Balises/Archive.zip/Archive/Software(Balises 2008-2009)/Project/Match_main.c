/*
 *	Club Robot ESEO 2008 - 2009
 *	Archi-Tech'
 *
 *	Fichier : Match_main.c
 *	Package : Projet Standard
 *	Description : fonction principale d'exemple pour le projet 
 *				standard construit par la QS pour exemple, pour
 *				utilisation en Match
 *	Auteur : Jacen
 *	Version 20080924
 */

#define MATCH_MAIN_C
#include "Match_main.h"
#ifdef MATCH_MODE
	
	
	
	void initialisation (void)
	{

		PORTS_init();
		ADC_init();
		TIMER_init();
		UART_init();  // ATTENTION : n'activez l'uart que si vous brancez le cable, sinon le code marche mal !		

		Beacon_init();
	}

	
	int main (void)
	{
		
		initialisation();
			
		while (1)
		{
			
//			process_telemeter();
			
			//Si on a recu un caract�re venant de l'uart...
			if(global.flags.u2rx)
				process_u2rx();
	
			//S'il est temps d'envoyer les donn�es o� si l'on a recu une donn�e � envoyer... on envoie !
			if(global.flags.timer2 == TRUE && (global.flag_envoi1 == TRUE || global.flag_envoi2 == TRUE || global.flag_envoi3 == TRUE ))
				process_timer();
			
			//Si une IT s'est d�clench�e depuis le dernier passage dans la boucle de main...
		//	if(global.flags.it)
		//		process_it();
		}
		
		return 0;		
	}
	
	
#endif /* def MATCH_MODE */
