  /*
 *	Club Robot ESEO 2009 - 2010
 *	
 *
 *	Fichier : main.h
 *	Package : Balises 2010
 *	Description : MAIN
 *	Auteur : Nirgal
 *	Version 200907
 */

#ifndef MAIN_H
	#define MAIN_H
	
	#include "QS/QS_all.h"

		
#endif /* ndef MAIN_H */
