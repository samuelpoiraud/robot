/*
 *	Club Robot ESEO 2008 - 2009
 *	Archi-Tech'
 *
 *	Fichier : QS_uart.h
 *	Package : Qualite Soft
 *	Description : fonction d'utilisation des uart pour 
 *				interfacage rs232
 *	Auteur : Jacen
 *	Version 20081010
 */

#ifndef QS_UART_H
	#define QS_UART_H

	#include "QS_all.h"
	#if !(defined(USE_UART1) || defined(USE_UART2) || defined(QS_UART_C))
		#error "QS_uart.h inclus sans declaration d'utilisation d'un uart"
	#endif

	/*	fonction initialisant les uart choisis
		vitesse : 9600 bauds
		bits de donnees : 8
		parite : aucune
		bit de stop : 1
		pas de controle de flux
	*/
	void UART_init(void);

	/*	fonction envoyant un octet sur l'uart correspondant */
	#ifdef USE_UART1
		void UART1_putc(Uint8 mes);
	#endif
	#ifdef USE_UART2
		void UART2_putc(Uint8 mes);
	#endif
	
	
	#ifdef QS_UART_C
		#include <uart.h>
	#endif /* def QS_UART_C */


#endif /* ndef QS_UART_H */
