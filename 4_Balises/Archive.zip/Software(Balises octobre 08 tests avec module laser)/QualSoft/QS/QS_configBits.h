/*
 *  Club Robot ESEO 2008 - 2009
 *  Archi-Tech'
 *
 *  Fichier : QS_configBits.h
 *  Package : Qualit� Soft
 *  Description : Configuration interne du PIC
 *  Auteur : Jacen
 *  Version 20081010
 */


#ifndef QS_CONFIGBITS_H
	#define QS_CONFIGBITS_H

	#ifdef QS_GLOBAL_VARS_C
		/* Bits de configuration du dsPIC .
		A besoin de se trouver apres le header du pic
		et seulement une fois dans le projet (classiquement le main) */
		#ifdef FREQ_10MHZ
			_FOSC(CSW_FSCM_OFF & XT_PLL4) /* XT PLL x4 & Failsafe clock off */
		#elif defined(FREQ_20MHZ)
			_FOSC(CSW_FSCM_OFF & XT_PLL8) /* XT PLL x8 & Failsafe clock off */
		#elif defined(FREQ_40MHZ)
			_FOSC(CSW_FSCM_OFF & XT_PLL16) /* XT PLL x16 & Failsafe clock off */
		#endif /* defined FREQ_xxMHZ */
		_FWDT(WDT_OFF) /* WatchDog off */
		_FBORPOR(PBOR_OFF & MCLR_EN) /* MCLR activ� & */
		_FGS(CODE_PROT_OFF) /* Disable code protection */

		__asm__(".global HEAPSIZE");
		__asm__(".equiv HEAPSIZE,0x100");

	#endif /* def QS_GLOBAL_VARS_C */

#endif /* ndef QS_CONFIGBITS_H */
