/*
 *  Club Robot ESEO 2006 - 2009
 *  Game Hoover, Archi-Tech'
 *
 *  Fichier : QS_can.h
 *  Package : Qualit� Soft
 *  Description : fonction CAN
 *  Auteur : Kim, revision par Jacen
 *  Version 20081010
 */
 

#ifndef QS_CAN_H
	#define QS_CAN_H
	#if !(defined(USE_CAN)||defined(USE_CAN2)||defined(QS_CAN_C))
		#error "QS_can.h inclus sans declaration d'utilisation du CAN"
	#endif /* !(defined(USE_CAN)||defined(USE_CAN2)||defined(QS_CAN_C)) */
	
	#include "QS_all.h"

	/* Prototype */	
	void CAN_init(void);
	void CAN_send(CAN_msg_t* can_msg);
	
	#ifdef QS_CAN_C
		#include <can.h>
		#define MASK_CAN_S			0x000 /* 0b00000000000 */
		/* on filtre les messages nous meme en aval */
		void CAN_receive(CAN_msg_t* can_msg);
		void _ISR _C1Interrupt(void);
	#endif /* def QS_CAN_C */
#endif
