/*
 *  Club Robot ESEO 2008 - 2009
 *  Archi-Tech'
 *
 *  Fichier : QS_timer.h
 *  Package : Qualit� Soft
 *  Description : Header de la gestion des timers
 *  Auteur : Jacen
 *  Version 20081023
 */

#ifndef QS_TIMER_H
	#define QS_TIMER_H

	#include "QS_all.h"

	void TIMER_init(void);
	void TIMER1_run(Uint8 period /* en millisecondes */);
	void TIMER1_stop(void);
	void TIMER2_run(Uint8 period /* en millisecondes */);
	void TIMER2_stop(void);
	void TIMER3_run(Uint8 period /* en millisecondes */);
	void TIMER3_run_us(Uint16 period /* en �s */);
	/*	note sur TIMER3_run_us :
	 *	la periode du timer ne peut pas d�passer
	 *	6553 �s � 10 MHz
	 *	3276 �s � 20 MHz
	 *	1638 �s � 40 MHz
	 */
	void TIMER3_stop(void);
	void TIMER4_run(Uint16 period /* en millisecondes */);
	void TIMER4_stop(void);

	
	#ifdef QS_TIMER_C
		#include <timer.h>

		#ifdef FREQ_10MHZ
			#define PULSE_PER_MS	39.0625
		#elif defined (FREQ_20MHZ)
			#define PULSE_PER_MS	78.125
		#else //40MHz
			#define PULSE_PER_MS	156.25
		#endif /* def FREQ_XXMHZ */
	
	#ifdef FREQ_10MHZ
			#define PULSE_PER_US	10
		#elif defined (FREQ_20MHZ)
			#define PULSE_PER_MS	20
		#else //40MHz
			#define PULSE_PER_MS	4s0
		#endif /* def FREQ_XXMHZ */

	#endif /* def QS_TIMER_C */

#endif
