/*
 *	Club Robot ESEO 2008 - 2009
 *	Archi-Tech'
 *
 *	Fichier : QS_pwm.h
 *	Package : Qualite Soft
 *	Description : fonction de manipulation des PWM du dsPIC30F6010A
 *					(PWM1H, PWM2H, PWM3H, PWM4H)
 *	Auteur : Jacen, d'apr�s le code d'Emmanuel FRADIN
 *	Version 20080815
 */
 
#ifndef QS_PWM_H
	#define QS_PWM_H
	#include "QS_all.h"
		
	void PWM_init(void);
	void PWM_stop(Uint8 voie);
	void PWM_run(Uint8 duty /* en pourcents*/, Uint8 voie);
	
	#ifdef QS_PWM_C
		#include <pwm.h>
		#define DEMI_PERIODE_PWM	400
	#endif /* def PWM_C */
#endif /* ndef PWH_H */
