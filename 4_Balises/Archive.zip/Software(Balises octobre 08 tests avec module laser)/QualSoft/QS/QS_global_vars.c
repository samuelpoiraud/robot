/*
 *  Club Robot ESEO 2008 - 2009
 *  Archi-Tech'
 *
 *  Fichier : QS_global_vars.c
 *  Package : Qualit� Soft
 *  Description : declaration de la structure contenant les
 *					variables globales
 *  Auteur : Jacen
 *  Version 20081012
 */

#define QS_GLOBAL_VARS_C

#include "QS_global_vars.h"

global_data_storage_t global;










