/*
 *  Club Robot ESEO 2008 - 2009
 *  Archi-Tech'
 *
 *  Fichier : Global_config.h
 *  Package : Standard_Project
 *  Description : Configuration des modules de QS
 *  Auteur : Jacen
 *  Version 20081010
 */

#ifndef GLOBAL_CONFIG_H
	#define GLOBAL_CONFIG_H
	#include "../QS/QS_types.h"

	/* En premier lieu, choisir si on souhaite executer un code de
	 * test ou le code de match */

	#define TEST_MODE
//	#define MATCH_MODE

	/* Pour certaines config particulieres, il faut definir qui on est
	 * a l'aide d'une des valeurs du type cartes_e de QS_types.h */
	#define I_AM BALISE

	/* Il faut choisir � quelle frequence on fait tourner le PIC */
	#define FREQ_10MHZ
//	#define FREQ_20MHZ
//	#define FREQ_40MHZ
	
	/* Les instructions ci dessous d�finissent le comportement des
	 * entrees sorties du pic. une configuration en entree correspond
	 * a un bit a 1 (Input) dans le masque, une sortie a un bit a
	 * 0 (Output).
	 * Toute connection non utilisee doit etre configuree en entree
	 * (risque de griller ou de faire bruler le pic) 
	 */

	#define PORT_A_IO_MASK	0xFFFF
	#define PORT_B_IO_MASK	0xFF03
		#define PORT_MOTEUR PORTB
		#define MOTEUR_ENABLEA	PORTBbits.RB6
		#define MOTEUR_ENABLEB	PORTBbits.RB7
		#define MOTEUR_INPUT1	PORTBbits.RB2
		#define MOTEUR_INPUT2	PORTBbits.RB3
		#define MOTEUR_INPUT3	PORTBbits.RB4
		#define MOTEUR_INPUT4	PORTBbits.RB5
	#define PORT_C_IO_MASK	0xFFFF

	
	#define PORT_D_IO_MASK	0xFFF0
		#define LED_V		PORTDbits.RD3
		#define LED_J		PORTDbits.RD2
		#define LED_R1		PORTDbits.RD1
		#define LED_R2		PORTDbits.RD0
	#define PORT_E_IO_MASK	0xFFE8
		#define PWM1L	PORTEbits.RE0
	#define PORT_F_IO_MASK	0xFFFF
		#define INT_EXTERNE PORTFbits.RF6	//=INT0
	#define PORT_G_IO_MASK	0xFFFF

	/* Les instructions suivantes permettent de configurer certaines
	 * entrees/sorties du pic pour realiser des fonctionnalites
	 * particulieres comme une entree analogique 
	 */

	#define USE_CAN
//	#define USE_CAN2
/*	Nombre de messages CAN conserv�s 
	pour traitement hors interuption */
	#define CAN_BUF_SIZE		4
//
//	#define USE_UART1
//	#define USE_UART1RXINTERRUPT
//	#define USE_UART2
//	#define USE_UART2RXINTERRUPT
/*	Taille de la chaine de caracteres memorisant
	les caracteres recus sur UART */
//	#define UART_RX_BUF_SIZE	12
//
//	#define USE_AN0
//	#define USE_AN1
//	#define USE_AN2
//	#define USE_AN3
//	#define USE_AN4
//	#define USE_AN5
//	#define USE_AN6
//	#define USE_AN7
//	#define USE_AN8
//	#define USE_AN9
//	#define USE_AN10
//	#define USE_AN11
//	#define USE_AN12
//	#define USE_AN13
//	#define USE_AN14
//	#define USE_AN15
//	#define USE_ANALOG_EXT_VREF

	
	
#endif /* ndef GLOBAL_CONFIG_H */
