/*
 *	Club Robot ESEO 2008 - 2009
 *	Archi-Tech'
 *
 *	Fichier : Test_main.c
 *	Package : Projet Standard
 *	Description : fonction principale d'exemple pour le projet 
 *				standard construit par la QS pour exemple, permettant
 *				l'appel des fonctions de test
 *	Auteur : Jacen
 *	Version 20081010
 */

#define TEST_MAIN_C
#include "Test_main.h"
#ifdef TEST_MODE

int laser_robot_en_face;
int nb_pas;
	int main (void)
	{
		PORTS_init();
		TIMER_init();
		PWM_init();
		moteur_init();
		laser_init();

//		CAN_msg_t can_msg;

		LED_V=1;
		TIMER3_run_us(3000);
		laser_robot_en_face=0;
	nb_pas = 0;

//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!ce code est exp�rimental, contactez samuel pour + d'infos !!!!!!!!!!!!!!!!!!!!!!!!!


	while(1){

	
	//	Doit-on changer de sens ?



		if(global.flags.timer3)	//si on vient de changer de pas du moteur
		{
		nb_pas=(nb_pas +1) %10;

		if(!global.laser_impulsions &&laser_robot_en_face)
		{
			global.moteur_sens=!global.moteur_sens;	//si on le voyait et qu'on le voit plus, on change de sens !
			
		}
		if (nb_pas==9)
			// a t'on eu des its laser pendant le pas effectu� ?
			{
			
		
			laser_robot_en_face = global.laser_impulsions; //pour le pas suivant, on m�morise si on voit le robot...
			}


			global.flags.timer3=0; 	//flag � 0.
			
	//		if(global.laser_impulsions)
	//			;
			
		
		
			
			//dans tout les cas, si on est en but�e, on impose le sens...
			
			if(global.moteur_position > MOTEUR_BUTEE_SUPERIEURE)
				global.moteur_sens=0;
			if(global.moteur_position < MOTEUR_BUTEE_INFERIEURE)
				global.moteur_sens=1;
			
			/*else if(global.moteur_position > global.moteur_destination)
				global.moteur_sens=0;
				*/

			if(nb_pas == 0)
				 global.laser_impulsions=0;
		}
		
			

	}

/* Dans cette interruption : gestion de la rotation du moteur, du sens...*/
//		LED_0=!LED_0;
			/*Mise � jour de la position*/
/*		if(POSITION < DESTINATION)
		{
			POSITION++;
			i++;
		}
		if(POSITION > DESTINATION)
		{
			POSITION--;
			i--;
		}
*/						
		/*PORTB=PORTB & 0xFFD3;*/
		/* pour �viter le crossconduction (cf Manu pour les explications) */
	//	i=(i+8)%8;		
		/* on place la valeur de nos bits de sortie */	
//		PORTB = /*0x00FC &*/ sortie[i] ;


		/*cf periph_timer.h et la d�finition de "sortie"*/
					
//		flag_IT_Moteur=1;		




		
		
/*		can_msg.sid = CARTE_ASSER_COULEUR;
		can_msg.data[0]=0;
		can_msg.taille =0;
		envoieMessageCAN(&can_msg);
			LED_BR=1;
		wait();
		can_msg.sid = BROADCAST_START;
		can_msg.taille =0;
		envoieMessageCAN(&can_msg);
		LED_EM=1;
		for(j=0; j < 10000000; j++); // attente 1 seconde
		can_msg.sid = CARTE_ASSER_GO_POSITION;
		can_msg.data[0]=2;
		can_msg.data[1]=0;
		can_msg.data[2]=2;
		can_msg.data[3]=0;
		can_msg.data[4]=0;
		can_msg.data[5]=0;
		can_msg.taille = 6;
		envoieMessageCAN(&can_msg);
		LED_PQ=1;

*/
		while(1){}
		return 0;
	}
#endif /* def TEST_MODE */
