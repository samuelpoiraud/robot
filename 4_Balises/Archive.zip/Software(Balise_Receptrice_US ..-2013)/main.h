/*
 *	Club Robot ESEO 2012
 *
 *	Fichier : main.h
 *	Package : Projet Standard
 *	Description : Gestion de la balise r�ceptrice Ultrason
 *	Auteur : Nirgal
 *	Version 201205
 */

#ifndef MAIN_H
	#define MAIN_H
	

	 
#endif /* ndef MAIN_H */
