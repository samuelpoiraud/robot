/*
 *  Club Robot ESEO 2015
 *
 *  Package : Balise �mettrice
 *  Description : Configuration globale
 *  Auteur : Arnaud
 */

#ifndef CONFIG_GLOBAL_H
	#define CONFIG_GLOBAL_H

	#define STM32F40XX

#endif /* ndef GLOBAL_CONFIG_H */
