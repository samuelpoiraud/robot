/*
 *  Club Robot ESEO 2015
 *
 *  Package : Balise �mettrice
 *  Description : Variable globale
 *  Auteur : Arnaud
 */

#include "config_global_vars.h"

global_data_storage_t global;

