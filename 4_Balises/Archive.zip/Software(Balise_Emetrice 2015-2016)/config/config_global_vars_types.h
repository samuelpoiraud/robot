/*
 *  Club Robot ESEO 2015
 *
 *  Package : Balise �mettrice
 *  Description : D�finition de types pour les variables globales
				d�finies specifiquement pour ce code.
 *  Auteur : Arnaud
 */

#ifndef CONFIG_GLOBAL_VARS_TYPES_H
	#define CONFIG_GLOBAL_VARS_TYPES_H

	#include "../QS/QS_types.h"

#endif /* ndef CONFIG_GLOBAL_VARS_TYPES_H */
