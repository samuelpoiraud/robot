/*
 *	Club Robot ESEO 2014
 *
 *	Fichier : QS_IHM.h
 *	Package : Carte IHM
 *	Description :
 *	Auteur : Anthony
 *	Version 2014/09/24
 */

#ifndef QS_IHM_H
	#define QS_IHM_H

	#include "QS_all.h"
#include "QS_CANmsgList.h"

	// Commenter pour d�sactiver la d�sactivation de la mise � jours de l'IHM pendant un match
	//#define IHM_SWITCH_DISABLE_IN_MATCH

	#define IHM_SWITCH_ON       0x80
	#define IHM_SWITCH_OFF		0x00
	#define IHM_SWITCH_MASK		0x7F

	// Ne pas set directement la led warning pass� par IHM_SET_ERROR qui g�re les erreurs multiples
	#define LED_WARNING			LED_3_IHM
	#define LED_SENSOR_TEST		LED_4_IHM

	typedef void(*ihm_button_action_t)(void);


	void IHM_init(volatile bool_e *matchStarted);

	// Message pour envoyer la configuration des leds
	// Assert : N'envoyer que 8 leds max
	// Appel : IHM_leds_send_msg(3,(led_ihm_t){LED_OK_IHM,BLINK_1HZ},(led_ihm_t){LED_1_IHM,OFF},(led_ihm_t){LED_2_IHM,ON});
	// Dans le cas de LED_COLOR_IHM � la place du blinking il faut renseigner la couleur selon led_color_e
	void IHM_leds_send_msg(Uint8 size, led_ihm_t led, ...);

	void IHM_set_led_color(led_color_e color);	//Modifier la couleur de la LED color.

	bool_e IHM_switchs_get(switch_ihm_e swit);

	void IHM_process_main(CAN_msg_t* msg);

	// long_push va �tre r�p�ter en boucle si on reste appuyer sur le boutton
	void IHM_define_act_button(button_ihm_e button_id,ihm_button_action_t direct_push, ihm_button_action_t after_long_push);


	// D�finitions des boutons
	#define BP_GO_TO_HOME			BP_GO_TO_HOME_IHM
	#define BP_OK					BP_OK_IHM
	#define BP_UP					BP_UP_IHM
	#define BP_DOWN					BP_DOWN_IHM
	#define BP_PRINTMATCH			BP_PRINTMATCH_IHM
	#define BP_SET					BP_SET_IHM
	#define BP_SUSPEND_RESUME_MATCH	BP_SUSPEND_RESUME_MATCH_IHM



	// D�finitions des switchs
	#define BIROUTE				BIROUTE_IHM
	#define SWITCH_COLOR		SWITCH_COLOR_IHM
	#define SWITCH_LCD			SWITCH_LCD_IHM

	#define SWITCH_RAW_DATA		SWITCH0_IHM
	#define SWITCH0_IHM_NAME	"SWITCH_RAW_DATA"

	#define SWITCH_VERBOSE		SWITCH1_IHM
	#define SWITCH1_IHM_NAME	"SWITCH_VERBOSE"

	#define SWITCH_XBEE			SWITCH2_IHM
	#define SWITCH2_IHM_NAME	"SWITCH_XBEE"

	#define SWITCH3_IHM_NAME	"SWITCH3"

	#define SWITCH_EVIT			SWITCH4_IHM
	#define SWITCH4_IHM_NAME	"SWITCH_EVIT"

	#define SWITCH5_IHM_NAME			"SWITCH5"
	#define SWITCH_PUSH_OUR_BLOC		SWITCH5_IHM      //Pearl : On doit pouss� le bloc situ� de notre c�t� de la zone de d�part
	#define SWITCH_RUSH                 SWITCH5_IHM      //Black : Rush

	#define SWITCH6_IHM_NAME			"SWITCH6"
	#define SWITCH_CLOSE_DOORS			SWITCH6_IHM      //Pearl: Commence par fermer les portes
	#define SWITCH_SA_DUNE_DIRECT        SWITCH6_IHM      //Black : Apr�s l'attente, Black fait directement la prise pelle. Si non-activ�, on fait d'abord la prise alternative ventouse avant la prise pelle

	#define SWITCH7_IHM_NAME			"SWITCH7"
	#define SWITCH_TAKE_DUNE_BLOC       SWITCH7_IHM      //Pearl et Black : On va prendre le bloc a cot� de la dune

	//#define SWITCH_STRAT_4			SWITCH8_IHM
	#define SWITCH8_IHM_NAME			"SWITCH8"
	#define SWITCH_COQUILLAGE_1         SWITCH8_IHM      //Configuration 1 des coquillages

	//#define SWITCH_STRAT_5			SWITCH9_IHM
	#define SWITCH9_IHM_NAME			"SWITCH9"
	#define SWITCH_COQUILLAGE_2         SWITCH9_IHM      //Configuration 2 des coquillages

	//#define SWITCH_STRAT_6			SWITCH10_IHM
	#define SWITCH10_IHM_NAME			"SWITCH10"
	#define SWITCH_COQUILLAGE_3         SWITCH10_IHM      //Configuration 3 des coquillages

	//#define SWITCH_STRAT_7			SWITCH11_IHM
	#define SWITCH11_IHM_NAME			"SWITCH11"
	#define SWITCH_COQUILLAGE_4         SWITCH11_IHM      //Configuration 4 des coquillages

	#define SWITCH12_IHM_NAME			"SW12"
	#define SWITCH_COQUILLAGE_5         SWITCH12_IHM      //Configuration 5 des coquillages

	#define SWITCH13_IHM_NAME			"SW13"
	#define SWITCH_DISABLE_DUNE         SWITCH13_IHM      //Black: D�sactivation de l'actionneur Dune
	#define SWITCH_ATTACK_FIRST         SWITCH13_IHM      //Pearl commence par les coquillages adverses

	#define SWITCH14_IHM_NAME			"SW14"
	#define SWITCH_DISABLE_SAND_BLOC    SWITCH14_IHM       //Black and Pearl : D�sactivation de la prise des blocs

	#define SWITCH15_IHM_NAME			"SW15"
	#define SWITCH_DISABLE_FISHS        SWITCH15_IHM       //Black et Pearl : D�sactivation de l'actionneur poissons

	#define SWITCH16_IHM_NAME			"SW16"
	#define SWITCH_DISABLE_SHOVEL        SWITCH16_IHM       //Black : D�sactivation de l'actionneur Dunix

	#define SWITCH17_IHM_NAME			"SW17"
	#define SWITCH_AGRESSIVITY          SWITCH17_IHM       //Black and Pearl : Si enable, le robot est plus agressif

	#define SWITCH18_DISABLE_ASSER		SWITCH18_IHM
	#define SWITCH18_IHM_NAME			"SW18 Disable ASSER"

#endif /* ndef QS_IHM_H */
