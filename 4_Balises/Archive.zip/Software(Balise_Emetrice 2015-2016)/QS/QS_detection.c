/*
 *  Club Robot ESEO 2015 - 2016
 *
 *  Fichier : QS_detection.c
 *  Package : Qualit� Soft
 *  Description : Module permettant de r�cup�rer les informations adversiare
 *  Auteur : Arnaud
 *  Version 20130518
 */


#include "QS_detection.h"
