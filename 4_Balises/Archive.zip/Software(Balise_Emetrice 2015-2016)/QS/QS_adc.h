/*
 *  Club Robot ESEO 2009 - 2013
 *
 *  Fichier : QS_adc.h
 *  Package : Qualit� Soft
 *  Description : Gestion du convertisseur analogique/num�rique
 *  Auteur : Alexis
 *  Version 20130518
 */

/** ----------------  Defines possibles  --------------------
 *
 *	USE_AN0						: Activation du convertisseur analogique 0
 *	USE_AN1						: Activation du convertisseur analogique 1
 *	USE_AN2						: Activation du convertisseur analogique 2
 *	USE_AN3						: Activation du convertisseur analogique 3
 *	USE_AN4						: Activation du convertisseur analogique 4
 *	USE_AN5						: Activation du convertisseur analogique 5
 *	USE_AN6						: Activation du convertisseur analogique 6
 *	USE_AN7						: Activation du convertisseur analogique 7
 *	USE_AN8						: Activation du convertisseur analogique 8
 *	USE_AN9						: Activation du convertisseur analogique 9
 *	USE_AN10					: Activation du convertisseur analogique 10
 *	USE_AN11					: Activation du convertisseur analogique 11
 *	USE_AN12					: Activation du convertisseur analogique 12
 *	USE_AN13					: Activation du convertisseur analogique 13
 *	USE_AN14					: Activation du convertisseur analogique 14
 *	USE_AN15					: Activation du convertisseur analogique 15
 *	USE_AN_TEMP_SENSOR			: Activation du convertisseur analogique du capteur de temp�rature de la STM32
*	USE_AN_VREFIN				: Activation du convertisseur analogique de la tension de r�f�rence interne
 *	USE_AN_VBAT					: Activation du convertisseur analogique de la tension batterie
 */

#ifndef QS_ADC_H
	#define QS_ADC_H

	#include "QS_all.h"

	/**
	 * @brief Enum�ration des convertisseurs analogique num�rique s�lectionnable
	 */
	typedef enum{
		ADC_0 = 0,
		ADC_1,
		ADC_2,
		ADC_3,
		ADC_4,
		ADC_5,
		ADC_6,
		ADC_7,
		ADC_8,
		ADC_9,
		ADC_10,
		ADC_11,
		ADC_12,
		ADC_13,
		ADC_14,
		ADC_15,
		ADC_TEMP_SENSOR,
		ADC_VREFIN,
		ADC_VBAT
	}adc_id_e;

	/**
	 * @brief Fonction d'initialisation des ADCs
	 */
	void ADC_init();

	/**
	 * @brief Cette fonction permet de r�cup�r� la valeur echantillonn�e d'un canal voulu
	 * @param channel : valeur de l'�num�ration adc_id_e
	 * @return la valeur echantillonn�e du canal
	 */
	Sint16 ADC_getValue(adc_id_e channel);

#endif /* ndef QS_ADC_H */
