/*
 *	Club Robot ESEO 2008 - 2009
 *	Archi-Tech'
 *
 *	Fichier : Laser.c
 *	Package : Balises
 *	Description : Utilisation du laser dans les balises, gestion des interruptions externes
 *	Auteur : Christophe Sambourg (utilisation de bouts de codes de phoboss 2008)
 *	Version 200810
 */

#define LASER_C

#include "laser.h"


void laser_init(void)
	{
		PWM_run(70,1);   
	// j'ai mis le rapport cyclique � 50% car dans nos test hard 
	//on l'avait fait ainsi, et la reception marchait

		//timer de scrutation de l'entr�e laser...
		TIMER1_run_us(30);	//Toutes les 30us, on scrute l'�tat...

	}


void _ISR _T1Interrupt(void)
	{	//interruption timer...
		if(RECEPTION_LASER==0)	
		{	//si le capteur nous dit qu'il recoit le laser... on incr�mente notre compteur
			global.laser_impulsions++;
			LED_4=1;	
		}
		else
			LED_4=0;
		_T1IF = 0;		/* Acquittement de l'IT */			
	}
