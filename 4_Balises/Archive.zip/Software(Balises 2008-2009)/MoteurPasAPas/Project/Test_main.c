/*
 *	Club Robot ESEO 2008 - 2009
 *	Archi-Tech'
 *
 *	Fichier : Test_main.c
 *	Package : Carte Balises
 *	Description : fonction principale permettant
 *				l'appel des fonctions de test de la carte balise
 *	Auteur : Christophe
 *	Version 20081209
 */

#define TEST_MAIN_C
#include "Test_main.h"
#ifdef TEST_MODE

int nb_pas;
int laser_robot_en_face;

	int main (void)
	{

		PORTS_init();
		TIMER_init();
		PWM_init();
		moteur_init();
		laser_init();
		LED_1 = 1;


		while (1)
		{

			//	Doit-on changer de sens ?
	
			if(global.flags.timer3)	//si on vient de changer de pas du moteur
			{
				LED_3 = !LED_3;
				if(global.laser_impulsions < 1 && laser_robot_en_face > 0)
					global.moteur_sens=!global.moteur_sens;
				laser_robot_en_face = global.laser_impulsions;
				global.laser_impulsions = 0;
				

				//dans tout les cas, si on est en but�e, on impose le sens...
					
					if(global.moteur_position > MOTEUR_BUTEE_SUPERIEURE)
						global.moteur_sens=0;
					if(global.moteur_position < MOTEUR_BUTEE_INFERIEURE)
						global.moteur_sens=1;

			global.flags.timer3=0;
			}
		}
		return 0;		
	}

#endif /* def TEST_MODE */



// SAUVEGARDE POUR INFO... mais a priori, c'est inutile.

	/*			nb_pas=(nb_pas +1) %10;
		
				if(!global.laser_impulsions &&laser_robot_en_face)
				{
					global.moteur_sens=!global.moteur_sens;	//si on le voyait et qu'on le voit plus, on change de sens !
					
				}
				if (nb_pas==9)
					// a t'on eu des its laser pendant le pas effectu� ?
					{
					
				
					laser_robot_en_face = global.laser_impulsions; //pour le pas suivant, on m�morise si on voit le robot...
					}
		
		
					global.flags.timer3=0; 	//flag � 0.
					
			//		if(global.laser_impulsions)
			//			;
	*/			


						
					/*else if(global.moteur_position > global.moteur_destination)
						global.moteur_sens=0;
						*/
		
				//	if(nb_pas == 0)
				//		 global.laser_impulsions=0;