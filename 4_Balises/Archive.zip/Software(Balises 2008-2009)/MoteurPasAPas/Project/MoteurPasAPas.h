/*
 *	Club Robot ESEO 2008 - 2009
 *	Archi-Tech'
 *
 *	Fichier : MoteurPasAPas.h
 *	Package : Balises
 *	Description : Utilisation du moteur pas a pas dans les balises
 *	Auteur : Christophe Sambourg (utilisation de bouts de codes de phoboss 2008)
 *	Version 200810
 */
 
#ifndef MOTEUR_PAS_A_PAS_H
	#define MOTEUR_PAS_A_PAS_H
	#include "../QS/QS_all.h"
	
	#include "../QS/QS_timer.h"	
		
	#define MOTEUR_BUTEE_SUPERIEURE 100
	#define MOTEUR_BUTEE_INFERIEURE -100

	#define MOTEUR_TEMPS 4
	//en ms, dur�e d'un pas du moteur

	void _ISR _T1Interrupt(void);
	void moteur_init(void);
	void moteur_test_rotation_continue(void);
	void moteur_changer_pas(void);
	void moteur_stop(void);		//arrete le moteur
	void moteur_start(void);	//lance le moteur

	#ifdef MOTEUR_PAS_A_PAS_C

//Ancienne carte... 2008		
//	Uint8 moteur_commandes[8]={0x00E0, 0x00E8, 0x00C8, 0x00D8, 0x00D0, 0x00D4, 0x00C4, 0x00E4};
//Nouvelle carte 2009...
	Uint8 moteur_commandes[8]={0x0038, 0x003A, 0x0032, 0x0036, 0x0034, 0x0035, 0x0031, 0x0039};
	Uint8 moteur_pas;	//num�ro du pas en cours (entre 0 et 8...)


	#endif /* def MOTEUR_PAS_A_PAS_C */
#endif /* ndef MOTEUR_PAS_A_PAS_H */
