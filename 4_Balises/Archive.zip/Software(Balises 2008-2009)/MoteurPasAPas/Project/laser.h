/*
 *	Club Robot ESEO 2008 - 2009
 *	Archi-Tech'
 *
 *	Fichier : laser.h
 *	Package : Balises
 *	Description : Utilisation du moteur pas a pas dans les balises
 *	Auteur : Christophe Sambourg (utilisation de bouts de codes de phoboss 2008)
 *	Version 200810
 */
 
#ifndef LASER_H
	#define LASER_H
	#include "../QS/QS_all.h"
	
	#include "../QS/QS_pwm.h"	
	#include "../QS/QS_timer.h"	

	void laser_init(void);

	#ifdef LASER_C
		


	#endif /* def LASER_C */
#endif /* ndef LASER_H */
