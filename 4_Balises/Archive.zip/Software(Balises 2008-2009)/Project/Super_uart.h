/*
 *	Club Robot ESEO 2008 - 2009
 *	Archi'Tech
 *
 *	Fichier : Super_uart.h
 *	Package : Supervision
 *	Description : fonctions de gestion des I/O sur uart.
 *	Auteur : Jacen
 *	Version 20081214
 */

#ifndef SUPER_UART_H
#define	SUPER_UART_H

#include "../QS/QS_all.h"
#include "../QS/QS_uart.h"
#include <stdio.h>

#define SOH 0x01
#define EOT 0x04

bool_e u1rxToCANmsg (CAN_msg_t* dest);
/*	
 *	cette fonction lit un octet dans le buffer de reception de l'uart1
 *	et compl�te le message CAN pass� en argument � partir du point o�
 *	elle s'est arret�e � son pr�c�dent appel. Elle renvoie ensuite si
 *	oui ou non elle a fini de compl�ter le message CAN
 */
 
 bool_e u2rxToCANmsg (CAN_msg_t* dest);
/*	
 *	cette fonction lit un octet dans le buffer de reception de l'uart2
 *	et compl�te le message CAN pass� en argument � partir du point o�
 *	elle s'est arret�e � son pr�c�dent appel. Elle renvoie ensuite si
 *	oui ou non elle a fini de compl�ter le message CAN. Elle v�rifie 
 *  aussi si le message est bien conforme au protocole de communication
 *  (cf QS)
 */


void CANmsgToU1tx (CAN_msg_t* src);
/*
 *	Ecrit le contenu du message CAN pass� en argument sur
 *	l'uart1
 */

void CANmsgToU2tx (CAN_msg_t* src);
/*
 *	Ecrit le contenu du message CAN pass� en argument sur
 *	l'uart1 en ajoutant l'octet SOH en d�but de message et l'octet EOT en fin de message (cf : protocole de communication QS)
 */
#endif /* ndef SUPER_UART_H */
