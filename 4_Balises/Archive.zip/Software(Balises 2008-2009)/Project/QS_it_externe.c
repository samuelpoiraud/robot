/*
 *	Club Robot ESEO 2008 - 2009
 *	Archi'Tech
 *
 *	Fichier : QS_pwm.c
 *	Package : Qualite Soft
 *	Description : fonction de manipulation des PWM du dsPIC30F6010A
 *					(PWM1H, PWM2H, PWM3H, PWM4H par defaut)
 *	Auteur : Jacen
 *	Version 20081205
 */

 
#define QS_IT_EXTERNE_C

#include "QS_it_externe.h"




	void IT_Externe_Enable(IT_e Channel, bool_e front)
	{
		switch(Channel)
		{
			case INT0:		
				INTCON2bits.INT0EP = front;
				_INT0IE = 1;
			break;
			case INT1:
				INTCON2bits.INT1EP = front;
				_INT1IE = 1;				
			break;
			case INT2:
				INTCON2bits.INT2EP = front;
				_INT2IE = 1;			
			break;
			case INT3:
				INTCON2bits.INT3EP = front;
				_INT3IE = 1;				
			break;
			default :
			break;
		}	
		IT_Externe_Acknowledge(Channel);
	}	
		
	void IT_Externe_Disable(IT_e Channel)
	{
	switch(Channel)
		{
			case INT0:		
				_INT0IE = 0;
				_INT0IF = 0;
			break;
			case INT1:
				_INT1IE = 0;				
				_INT1IF = 0;
			break;
			case INT2:
				_INT2IE = 0;
				_INT2IF = 0;			
			break;
			case INT3:
				_INT3IE = 0;
				_INT3IF = 0;				
			break;
			default :
			break;
		}	
	}	
	
			
	void IT_Externe_Acknowledge(IT_e Channel)
	{
	switch(Channel)
		{
			case INT0:		
				_INT0IF = 0;
			break;
			case INT1:
				_INT1IF = 0;				
			break;
			case INT2:
				_INT2IF = 0;			
			break;
			case INT3:
				_INT3IF = 0;				
			break;
			default :
			break;
		}	
	}	
