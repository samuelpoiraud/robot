#include <stdio.h>
#include <stdlib.h>

int main(void)
{
 printf("bonjour\n");


	FILE* fichier=NULL;
	fichier=fopen("tableau.txt","r+");		//ouverture du fichier
	if (fichier==NULL)
	{
		printf("erreur");
		return 1;		// si pb return 0
	}

	FILE* out_x=NULL;
	FILE* out_y=NULL;
	out_x=fopen("out_x.txt","w+");
	out_y=fopen("out_y.txt","w+");
	if (out_x==NULL || out_y == NULL)
	{
		printf("erreur2");
		return 1;		// si pb return 0
	}


	char s[100]="";
	int tableau_x[127][127];
	int tableau_y[127][127];

	int a,b,x,y,i=0,j=0,k=0;

	for(k=0;k<127;k++)
		for(j=0;j<127;j++)
		{
			tableau_x[k][j] = 32767;
			tableau_y[k][j] = 32767;
		}

	while(fscanf(fichier,"%d\t%d\t%d\t%d",&a,&b,&x,&y)!=EOF)
	{
		if((a+b>128) && (x || y))
			printf("%d   a:%d, b:%d, x:%d, y:%d\n",i,a,b,x,y);

		if(a+b<=128)
		{
			if(b<65)
			{
				tableau_x[b-1][a-1] = x;//b*1000+a;
				tableau_y[b-1][a-1] = y;
			}
			else
			{
				tableau_x[127-b+1][127-a] = x;// b*1000+a;
				tableau_y[127-b+1][127-a] = y;// b*1000+a;
			}
		}

		i++;
	//	printf("%d   a:%d, b:%d, x:%d, y:%d\n",i,a,b,x,y);
	}
 	fclose(fichier);

	fprintf(out_x,"{");
	fprintf(out_y,"{");
	for(k=0;k<65;k++)
	{
		fprintf(out_x,"{");
		fprintf(out_y,"{");
		for(j=0;j<127;j++)
		{
			fprintf(out_x,"%d,",tableau_x[k][j]);
			fprintf(out_y,"%d,",tableau_y[k][j]);
			//tableau_y[k][j] = 0;
		}
		fprintf(out_x,"%d},\n",tableau_x[k][126]);
		fprintf(out_y,"%d},\n",tableau_y[k][126]);
		//printf("\n_%d_: ",k);
	}
	fprintf(out_x,"};");
	fprintf(out_y,"};");
	fclose(out_x);
	fclose(out_y);



return 0;
}

